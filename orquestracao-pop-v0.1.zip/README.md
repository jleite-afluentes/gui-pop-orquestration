# Pacote de orquestração de POP

Skill para Codex com instruções, referências e controles locais em Python 3.9+. O pacote não contém dados de empresas, nem instala ferramentas externas ou modelos de IA. Não é necessário Laya para usá-lo.

## Instalação por participante

1. Descompacte o pacote em local de sua escolha.
2. No terminal, execute `./instalar.sh`. O script copia a skill para `${CODEX_HOME:-~/.codex}/skills/orquestrar-pop` e não sobrescreve uma instalação existente.
3. Reinicie o Codex se necessário e invoque `$orquestrar-pop`, indicando a pasta da empresa no Google Drive. A skill solicitará os insumos e conduzirá os gates.

Cada participante precisa de acesso autorizado à pasta da empresa e das ferramentas de criação de DOCX, PDF, PPTX e BPMN. O instalador não fornece essas ferramentas; sua disponibilidade e capacidade de gerar os formatos na pasta devem ser verificadas no ambiente. Laya, se escolhido futuramente, requer instalação e avaliação independentes.

## Controles

`python3 skills/orquestrar-pop/scripts/pop.py --help` apresenta os comandos locais. Eles criam estruturas, validam referências declaradas, geram e verificam manifestos, registram aprovação autodeclarada e reservas locais. Não criam automaticamente os documentos finais, não validam semântica ou BPMN e não garantem bloqueio distribuído na sincronização do Drive. Não inclua dados sensíveis em argumentos de comandos compartilhados.

O arquivo `ARQUITETURA-E-CRITERIOS.md` acompanha o pacote como referência de projeto. A implementação é inicial: geração de artefatos depende das skills e ferramentas disponíveis; não há grafo automático, máquina de estados executável, análise semântica, detecção garantida de conflitos distribuídos ou integração Laya. O piloto posterior deverá verificar o fluxo integral e os limites de cada ambiente.
