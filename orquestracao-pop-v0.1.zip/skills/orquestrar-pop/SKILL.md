---
name: orquestrar-pop
description: Elaborar, revisar ou retomar POPs empresariais com contexto compartilhado, BPMN, RACI, aprovação do owner e entregas Markdown, DOCX, PDF, PPTX e guia HTML offline.
---

# Orquestração de POP

Coordene o trabalho em português e mantenha o estado em arquivos da empresa. Ao iniciar ou retomar, solicite ou identifique a pasta da empresa, POP, usuário/owner e fontes. Use `scripts/pop.py` conforme `references/operacao.md`; não invente dados ou declare verificações não executadas. Solicite confirmação de identidade quando não verificada. Faça perguntas em rodadas, com recomendações, para lacunas materiais; consulte documentos antes de perguntar o que já está disponível.

Leia `references/fluxo.md` para gates, autonomia, revisão e métodos. Leia `references/entregas.md` quando produzir ou verificar as entregas. Em cada etapa leia apenas arquivos pertinentes e preserve referências e versões. Respeite permissões reais do ambiente; se uma ferramenta faltar, registre bloqueio e proponha alternativa, sem declarar que a entrega existe.

Separe fatos, hipóteses e melhorias. Decisões de alta complexidade ou que afetem segurança, conformidade, responsabilidades ou passos essenciais são decididas pelo usuário; registre decisões autônomas e fontes. Revisão crítica é independente da autoria. O owner é o único aprovador final; apresente artefatos, pendências e decisões antes de registrar sua aprovação explícita. Preserve versões aprovadas.

O Markdown é a referência de conteúdo, o BPMN a representação do processo; IDs vinculam atividades e papéis à RACI. Investigue divergências e faça análise de impacto; o validador local é estrutural e não verifica coerência semântica nem conformidade BPMN. Use Laya apenas opcionalmente em observação, se instalado e avaliado; ausência não impede trabalho.

Não execute automaticamente implantação, compartilhamento, publicação ou edição de documentos de terceiros. O projeto identifica conflitos de sincronização apenas de modo limitado; confirme o estado atual antes de gravar e nunca afirme exclusão mútua no Drive.
